﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        InventoryManager inventoryManager = new InventoryManager();

        // Add some initial items to the inventory
        inventoryManager.AddItem(new Item("Item 1", 10.99, 5));
        inventoryManager.AddItem(new Item("Item 2", 5.99, 10));
        inventoryManager.AddItem(new Item("Item 3", 2.99, 3));

        while (true)
        {
            Console.WriteLine("Inventory Manager Menu:");
            Console.WriteLine("1. Add Item");
            Console.WriteLine("2. Remove Item");
            Console.WriteLine("3. Re-stock Item");
            Console.WriteLine("4. Display Items");
            Console.WriteLine("5. Search for Item");
            Console.WriteLine("6. Exit");
            Console.WriteLine();

            Console.Write("Enter your choice (1-6): ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    Console.Write("Enter the item name: ");
                    string name = Console.ReadLine();
                    Console.Write("Enter the item price: ");
                    double price = Convert.ToDouble(Console.ReadLine());
                    Console.Write("Enter the item quantity: ");
                    int quantity = Convert.ToInt32(Console.ReadLine());

                    inventoryManager.AddItem(new Item(name, price, quantity));
                    Console.WriteLine("Item added successfully.");
                    break;
                case "2":
                    Console.Write("Enter the item name to remove: ");
                    string itemName = Console.ReadLine();
                    inventoryManager.RemoveItem(itemName);
                    Console.WriteLine("Item removed successfully.");
                    break;
                case "3":
                    Console.Write("Enter the item name to re-stock: ");
                    string itemToRestock = Console.ReadLine();
                    Console.Write("Enter the quantity to add: ");
                    int quantityToAdd = Convert.ToInt32(Console.ReadLine());
                    inventoryManager.RestockItem(itemToRestock, quantityToAdd);
                    Console.WriteLine("Item re-stocked successfully.");
                    break;
                case "4":
                    Console.WriteLine("Items in the inventory:");
                    inventoryManager.DisplayItems();
                    break;
                case "5":
                    Console.WriteLine("Search for an item:");
                    Console.Write("Enter the search criteria: ");
                    string searchCriteria = Console.ReadLine();
                    List<Item> searchResults = inventoryManager.SearchItems(searchCriteria);
                    if (searchResults.Count > 0)
                    {
                        Console.WriteLine("Search results:");
                        foreach (Item item in searchResults)
                        {
                            Console.WriteLine(item.ToString());
                        }
                    }
                    else
                    {
                        Console.WriteLine("No items found matching the search criteria.");
                    }
                    break;
                case "6":
                    Console.WriteLine("Exiting program...");
                    return;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }

            Console.WriteLine();
        }
    }
}

class Item
{
    public string Name { get; set; }
    public double Price { get; set; }
    public int Quantity { get; set; }

    public Item(string name, double price, int quantity)
    {
        Name = name;
        Price = price;
        Quantity = quantity;
    }

    public override string ToString()
    {
        return $"Name: {Name}, Price: {Price:C}, Quantity: {Quantity}";
    }
}

class InventoryManager
{
    private List<Item> inventory;

    public InventoryManager()
    {
        inventory = new List<Item>();
    }

    public void AddItem(Item item)
    {
        inventory.Add(item);
    }

    public void RemoveItem(string itemName)
    {
        Item itemToRemove = inventory.Find(item => item.Name == itemName);
        if (itemToRemove != null)
        {
            inventory.Remove(itemToRemove);
        }
        else
        {
            Console.WriteLine("Item not found in the inventory.");
        }
    }

    public void RestockItem(string itemName, int quantityToAdd)
    {
        Item itemToRestock = inventory.Find(item => item.Name == itemName);
        if (itemToRestock != null)
        {
            itemToRestock.Quantity += quantityToAdd;
        }
        else
        {
            Console.WriteLine("Item not found in the inventory.");
        }
    }

    public void DisplayItems()
    {
        foreach (Item item in inventory)
        {
            Console.WriteLine(item.ToString());
        }
    }

    public List<Item> SearchItems(string searchCriteria)
    {
        List<Item> searchResults = inventory.FindAll(item => item.Name.Contains(searchCriteria));
        return searchResults;
    }
}